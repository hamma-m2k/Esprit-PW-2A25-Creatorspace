<?php
/**
 * Demande.php — Entité Demande d'inscription
 * Représente une demande avec ses attributs, constructeur, getters et setters.
 * Aucune logique SQL ici.
 */
class Demande {

    private int    $id;
    private string $nom;
    private string $prenom;
    private string $mail;
    private string $password;
    private string $typeCompte;
    private string $statut;
    private string $createdAt;

    public function __construct(
        int    $id         = 0,
        string $nom        = '',
        string $prenom     = '',
        string $mail       = '',
        string $password   = '',
        string $typeCompte = 'user',
        string $statut     = 'en_attente',
        string $createdAt  = ''
    ) {
        $this->id         = $id;
        $this->nom        = $nom;
        $this->prenom     = $prenom;
        $this->mail       = $mail;
        $this->password   = $password;
        $this->typeCompte = $typeCompte;
        $this->statut     = $statut;
        $this->createdAt  = $createdAt;
    }

    // ── Getters ───────────────────────────────────────────────

    public function getId(): int            { return $this->id; }
    public function getNom(): string        { return $this->nom; }
    public function getPrenom(): string     { return $this->prenom; }
    public function getMail(): string       { return $this->mail; }
    public function getPassword(): string   { return $this->password; }
    public function getTypeCompte(): string { return $this->typeCompte; }
    public function getStatut(): string     { return $this->statut; }
    public function getCreatedAt(): string  { return $this->createdAt; }

    // ── Setters ───────────────────────────────────────────────

    public function setId(int $id): void             { $this->id = $id; }
    public function setNom(string $nom): void        { $this->nom = $nom; }
    public function setPrenom(string $prenom): void  { $this->prenom = $prenom; }
    public function setMail(string $mail): void      { $this->mail = $mail; }
    public function setPassword(string $p): void     { $this->password = $p; }
    public function setTypeCompte(string $t): void   { $this->typeCompte = $t; }
    public function setStatut(string $s): void       { $this->statut = $s; }
    public function setCreatedAt(string $d): void    { $this->createdAt = $d; }

    // ── Helper : construit une Demande depuis un tableau PDO ──

    public static function fromArray(array $row): self {
        return new self(
            (int)($row['id']          ?? 0),
            $row['nom']               ?? '',
            $row['prenom']            ?? '',
            $row['mail']              ?? '',
            $row['password']          ?? '',
            $row['type_compte']       ?? 'user',
            $row['statut']            ?? 'en_attente',
            $row['created_at']        ?? ''
        );
    }

    // ── Helper : convertit en tableau (pour les vues) ─────────

    public function toArray(): array {
        return [
            'id'          => $this->id,
            'nom'         => $this->nom,
            'prenom'      => $this->prenom,
            'mail'        => $this->mail,
            'password'    => $this->password,
            'type_compte' => $this->typeCompte,
            'statut'      => $this->statut,
            'created_at'  => $this->createdAt,
        ];
    }
}
