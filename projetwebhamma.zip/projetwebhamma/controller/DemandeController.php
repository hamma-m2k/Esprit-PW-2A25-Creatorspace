<?php
// controller/DemandeController.php — no HTML, no SQL
// session_start() géré dans index.php

require_once __DIR__ . '/../model/config.php';
require_once __DIR__ . '/../model/UserModel.php';
require_once __DIR__ . '/../model/DemandeModel.php';

// Admin uniquement
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php?ctrl=auth&action=login');
    exit;
}

$userModel    = new UserModel($pdo);
$demandeModel = new DemandeModel($pdo);
$action       = $_GET['action'] ?? 'liste';

switch ($action) {

    case 'liste':
        $demandes       = $demandeModel->getEnAttente();
        $totalEnAttente = $demandeModel->countEnAttente();
        $currentUser    = [
            'initials' => strtoupper(substr($_SESSION['nom'] ?? 'A', 0, 2)),
            'name'     => $_SESSION['nom']  ?? '',
            'role'     => $_SESSION['role'] ?? '',
            'color'    => '#6C3FC5',
        ];
        $page = 'demandes';
        require_once __DIR__ . '/../view/backoffice/demandes.php';
        break;

    case 'historique':
        $demandes    = $demandeModel->getAll();
        $currentUser = [
            'initials' => strtoupper(substr($_SESSION['nom'] ?? 'A', 0, 2)),
            'name'     => $_SESSION['nom']  ?? '',
            'role'     => $_SESSION['role'] ?? '',
            'color'    => '#6C3FC5',
        ];
        $page = 'demandes';
        require_once __DIR__ . '/../view/backoffice/demandes_historique.php';
        break;

    case 'accepter':
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $demandeModel->accepter($id, $userModel);
            $_SESSION['success_demande'] = "Compte créé avec succès.";
        }
        header('Location: index.php?ctrl=demande&action=liste');
        exit;

    case 'refuser':
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $demandeModel->refuser($id);
            $_SESSION['success_demande'] = "Demande refusée.";
        }
        header('Location: index.php?ctrl=demande&action=liste');
        exit;

    default:
        header('Location: index.php?ctrl=demande&action=liste');
        exit;
}
