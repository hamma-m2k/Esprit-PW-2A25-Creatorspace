<?php
// controller/AuthController.php — no HTML, no SQL
// session_start() géré dans index.php

require_once __DIR__ . '/../model/config.php';
require_once __DIR__ . '/../model/UserModel.php';

$model  = new UserModel($pdo);
$action = $_GET['action'] ?? 'login';

switch ($action) {

    // ── LOGIN ─────────────────────────────────────────────────
    case 'login':
        $success = '';
        if (!empty($_SESSION['success_register'])) {
            $success = $_SESSION['success_register'];
            unset($_SESSION['success_register']);
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $mail     = trim($_POST['mail']     ?? '');
            $password = trim($_POST['password'] ?? '');
            $user     = $model->getByMail($mail); // retourne un objet User ou null

            if ($user && md5($password) === $user->getPassword()) {
                $_SESSION['user_id'] = $user->getId();
                $_SESSION['nom']     = $user->getNom();
                $_SESSION['role']    = $user->getRole();
                $_SESSION['mail']    = $user->getMail();

                if ($user->getRole() === 'admin') {
                    header('Location: index.php?ctrl=user&action=dashboard');
                } else {
                    header('Location: index.php?ctrl=user&action=profile');
                }
                exit;
            }

            $error = "Email ou mot de passe incorrect.";
            require_once __DIR__ . '/../view/auth/login.php';

        } else {
            $error = '';
            require_once __DIR__ . '/../view/auth/login.php';
        }
        break;

    // ── REGISTER ──────────────────────────────────────────────
    case 'register':
        if (isset($_SESSION['user_id'])) {
            header('Location: index.php?ctrl=user&action=profile');
            exit;
        }
        require_once __DIR__ . '/../model/config.php';
        require_once __DIR__ . '/../model/UserModel.php';
        require_once __DIR__ . '/../model/DemandeModel.php';
        $userModel    = new UserModel($pdo);
        $demandeModel = new DemandeModel($pdo);
        $errors = [];
        $old    = [];
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nom      = trim($_POST['nom']         ?? '');
            $prenom   = trim($_POST['prenom']      ?? '');
            $mail     = trim($_POST['mail']        ?? '');
            $password = trim($_POST['password']    ?? '');
            $type     = trim($_POST['type_compte'] ?? '');

            // Validation PHP PURE — ZÉRO HTML5
            if ($nom === '')
                $errors['nom'] = "Ce champ est obligatoire.";
            elseif (!preg_match('/^[a-zA-ZÀ-ÿ\s\-]+$/u', $nom))
                $errors['nom'] = "Le nom ne doit contenir que des lettres.";

            if ($prenom === '')
                $errors['prenom'] = "Ce champ est obligatoire.";
            elseif (!preg_match('/^[a-zA-ZÀ-ÿ\s\-]+$/u', $prenom))
                $errors['prenom'] = "Le prénom ne doit contenir que des lettres.";

            if ($mail === '')
                $errors['mail'] = "Ce champ est obligatoire.";
            elseif (!str_ends_with($mail, '@gmail.com'))
                $errors['mail'] = "L'email doit se terminer par @gmail.com.";
            elseif ($userModel->mailExiste($mail, 0))
                $errors['mail'] = "Cet email est déjà utilisé.";
            elseif ($demandeModel->mailEnAttente($mail))
                $errors['mail'] = "Une demande est déjà en attente pour cet email.";

            if ($password === '')
                $errors['password'] = "Ce champ est obligatoire.";

            $typesValides = ['user', 'societe', 'createur'];
            if (!in_array($type, $typesValides))
                $errors['type_compte'] = "Veuillez choisir un type de compte.";

            if (empty($errors)) {
                $demandeModel->creerDemande([
                    'nom'         => $nom,
                    'prenom'      => $prenom,
                    'mail'        => $mail,
                    'password'    => $password,
                    'type_compte' => $type,
                ]);
                $_SESSION['msg_register'] = "Votre demande a été envoyée. Elle sera traitée par l'administrateur.";
                header('Location: index.php?ctrl=auth&action=login');
                exit;
            }
            $old = $_POST;
        }
        require_once __DIR__ . '/../view/auth/register.php';
        break;

    // ── LOGOUT ────────────────────────────────────────────────
    case 'logout':
        session_unset();
        session_destroy();
        header('Location: index.php?ctrl=auth&action=login');
        exit;

    default:
        $error = '';
        require_once __DIR__ . '/../view/auth/login.php';
        break;
}
